document.addEventListener("deviceready", function(){
  
}, false);
