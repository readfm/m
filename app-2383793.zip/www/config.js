window.Cfg = {
	server: 'io.cx/',
	defaultYoutube: '/8OgeqEhVRvU&t=14.6;4',
	files: 'http://files.mp3gif.com/',
	thumber: 'http://thumb.pix8.co/',
	collection: 'pix8',

	wiki: 'http://wiki.io.cx/',
	tag: 'picture',

	apis: {},

	drag: {
		takeOffLimit: 5,
		dy: 15,
		dx: 10
	},

	collector: {
		minWidth: 60,
		minHeight: 60,
		limit: 20
	},

	limits: {
		minPix8Height: 40,
		minFrameHeight: 100,
		minControlHeight: 80
	},

	textdata: {
		limit: 190
	},

	auth: {
		site: 'http://auth.io.cx',
		avatar: 'http://auth.io.cx/user',
		google: 'http://taitis.com/auth/google'
	},

	ggif: {
		audioFormat: 'mp3',
		shadowOffsetX: 2,
		shadowOffsetY: 2,
		shadowBlur: 2,
		shadowColor: "#000",
		font: 'Courier New',
		color: '#FFF',
		size: 12,
		gradient1: '#000',
		gradient2: 'rgba(0,0,0,0.3)'
	},


	game: {
		startLimit: 3
	}
};


var User = window.User = {
	id: '103915987270794097143',
	name: 'anonymous'
}
