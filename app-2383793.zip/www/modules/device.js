window.Device = {
  initInfo: function(cb){
    this.plugin = cordova.require("cordova-plugin-deviceinformation.DeviceInformation");
    this.plugin.get(function(result){
        Device.info = JSON.parse(result);
        cb()
    }, function(){
        console.error("no device info found");
    });
  },

  findGname: function(cb){
    Device.info.accounts.forEach(function(acc){
      if(acc.type == 'com.google'){
        var g = acc.email.split('@');

        var name;
        if(g[1] == 'gmail.com')
          name = g[0];
        else
          name = acc.email;

        Device.gName = name;
        cb(name);
      }
    });
  }
};

document.addEventListener("deviceready", function(){
  Device.initInfo(function(){
    Device.findGname(function(name){
      User.name = name;
    });
  });
});
