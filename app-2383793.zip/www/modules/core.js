window.C = console;
window.log = function(text){
	console.log(text);
}