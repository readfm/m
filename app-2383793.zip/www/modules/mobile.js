$(function(){
	$('#exit').click(function(){
		navigator.app.exitApp();
	});
});

document.addEventListener("pause", function(argument){
	navigator.app.exitApp();
}, false);
